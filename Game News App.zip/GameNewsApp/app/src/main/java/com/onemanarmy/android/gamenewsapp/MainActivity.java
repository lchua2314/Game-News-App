package com.onemanarmy.android.gamenewsapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    public static final String consumerKey = BuildConfig.CONSUMER_KEY;
    public static final String NOW_PLAYING_URL = "http://www.gamespot.com/api/releases/?api_key=" + consumerKey;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}